<?php

namespace App\Imports;

use App\Models\research_management;
use Maatwebsite\Excel\Concerns\ToModel;

class UsersImport implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new research_management([
            'title'     => $row[1],
            'url_title'    => $row[2],
            'industry_id' => $row[3],
        ]);
    }
}
