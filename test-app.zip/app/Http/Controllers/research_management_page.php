<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\research_management;
use App\Models\client_new;
use DB;
class research_management_page extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
		$posts = research_management::orderBy('id','desc')->paginate(5);
        $titled = DB::table('client_news')->select('id','name')->get();
        return view('report_management',compact('titled','posts'));
		
    }
	

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		
        $request->validate([
		 'title'=>'required',
		 'url_title'=>'required',
		 'region'=>'required',
		 'industry_id'=>'required',
		 'page_count'=>'required',
		 'price_single_user'=>'required',
		 'single_user_discount'=>'required',
		 'price_multi_user'=>'required',
		 'multi_user_discount'=>'required',
		 'price_industry_user'=>'required',
		 'industry_user_discount'=>'required',
		 'm_title'=>'required',
		 'm_keywords'=>'required',
		 'm_description'=>'required',
		 'article_text'=>'required',
		 'company_mentioned'=>'required',
		 'table_content'=>'required',
		 
		]);
		$research_management = new research_management;
        $research_management->title = $request->title;
        $research_management->url_title = $request->url_title;
        $research_management->region = $request->region;
        $research_management->industry_id = $request->industry_id;
        $research_management->page_count = $request->page_count;
        $research_management->price_single_user = $request->price_single_user;
        $research_management->single_user_discount = $request->single_user_discount;
        $research_management->price_multi_user = $request->price_multi_user;
        $research_management->multi_user_discount = $request->multi_user_discount;
        $research_management->price_industry_user = $request->price_industry_user;
        $research_management->industry_user_discount = $request->industry_user_discount;
        $research_management->m_title = $request->m_title;
        $research_management->m_keywords = $request->m_keywords;
        $research_management->m_description = $request->m_description;
        $research_management->article_text = $request->article_text;
        $research_management->company_mentioned = $request->company_mentioned;
        $research_management->table_content = $request->table_content;
		
		$research_management->faq_keyword = $request->faq_keyword;
		$research_management->ques1 = $request->ques1;
		$research_management->ques2 = $request->ques2;
		$research_management->ques3 = $request->ques3;
		$research_management->ques4 = $request->ques4;
		$research_management->ques5 = $request->ques5;
		$research_management->ques6 = $request->ques6;
		$research_management->ques8 = $request->ques8;
		$research_management->ans8 = $request->ans8;
		$research_management->ques9 = $request->ques9;
		$research_management->ans9 = $request->ans9;
		$research_management->delete_status = '0';
        $research_management->save();
		$request->session()->flash('success','Report has been created successfully.');
		  return redirect('report_management');		
    }

     //Start Search
	
	function AjaxIndex()
    {
     return view('live_search');
    }
	function action(Request $request)
    {
     if($request->ajax())
     {
      $output = '';
      $query = $request->get('query');
      if($query != '')
      {
       $data = DB::table('research_managements')
         ->where('id', 'like', '%'.$query.'%')
         ->orWhere('title', 'like', '%'.$query.'%')
         ->orWhere('article_text', 'like', '%'.$query.'%')
         ->orderBy('id', 'desc')
         ->get();
         
      }
      else
      {
	   $data = DB::table('research_managements')
         ->orderBy('id', 'desc')
		 ->limit(10)
         ->get();
		/* 
	$data = DB::table('research_managements')
    ->join('client_news', 'research_managements.industry_id', '=', 'client_news.id')
	->select('research_managements.*','client_news.name as name')
    ->get();
	*/
	
      }
      $total_row = $data->count();
      // print_r($total_row);exit;
	  if($total_row > 0)
      {
       foreach($data as $row)
       {
        $output .= '
        <tr>
         <td>'.$row->id.'</td>
         
         <td style="width:200px">'.$row->title.'</td>
         <td>'.substr($row->article_text,0,100).'</td>
		 <td>
		  <form action="/destroy" method="POST">
    
                    <a class="btn btn-primary" href="edit_report/'.$row->id.'">Edit</a>
                    <a class="btn btn-danger" href="destroy/'.$row->id.'">Delete</a>
   
                    
                    
      
                    <!--<button type="submit" class="btn btn-danger">Delete</button>-->
                </form>
		 </td>
         </tr>
        ';
       }
      }
      else
      {
       $output = '
       <tr>
        <td align="center" colspan="5">No Data Found</td>
       </tr>
       ';
      }
      $data = array(
       'table_data'  => $output,
       'total_data'  => $total_row
      );

      echo json_encode($data);
     }
    }
	
	
	//End Search
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $research_m = research_management::find($id);
		//$data['posts'] = Post::orderBy('id','desc')->paginate(5);
		// $title = DB::table('client_news')->select('id','name')->get();
		$title = client_new::orderBy('id','desc')->paginate(5);
		// dd($title);
		$region = ['Global','Country','Regional'];
        return view('edit_report_management',compact('research_m','title','region'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update_report(Request $request, $id)
    {
        
		$request->validate([
		 'title'=>'required',
		 'url_title'=>'required',
		 'region'=>'required',
		 'industry_id'=>'required',
		 'page_count'=>'required',
		 'price_single_user'=>'required',
		 'single_user_discount'=>'required',
		 'price_multi_user'=>'required',
		 'multi_user_discount'=>'required',
		 'price_industry_user'=>'required',
		 'industry_user_discount'=>'required',
		 'm_title'=>'required',
		 'm_keywords'=>'required',
		 'm_description'=>'required',
		 'article_text'=>'required',
		 'company_mentioned'=>'required',
		 'table_content'=>'required',
		 
		]);
		$research_management = research_management::find($id);
		$research_management->title = $request->title;
        $research_management->url_title = $request->url_title;
        $research_management->region = $request->region;
        $research_management->industry_id = $request->industry_id;
        $research_management->page_count = $request->page_count;
        $research_management->price_single_user = $request->price_single_user;
        $research_management->single_user_discount = $request->single_user_discount;
        $research_management->price_multi_user = $request->price_multi_user;
        $research_management->multi_user_discount = $request->multi_user_discount;
        $research_management->price_industry_user = $request->price_industry_user;
        $research_management->industry_user_discount = $request->industry_user_discount;
        $research_management->m_title = $request->m_title;
        $research_management->m_keywords = $request->m_keywords;
        $research_management->m_description = $request->m_description;
        $research_management->article_text = $request->article_text;
        $research_management->company_mentioned = $request->company_mentioned;
        $research_management->table_content = $request->table_content;
		$research_management->faq_keyword = $request->faq_keyword;
		$research_management->ques1 = $request->ques1;
		$research_management->ques2 = $request->ques2;
		$research_management->ques3 = $request->ques3;
		$research_management->ques4 = $request->ques4;
		$research_management->ques5 = $request->ques5;
		$research_management->ques6 = $request->ques6;
		$research_management->ques8 = $request->ques8;
		$research_management->ans8 = $request->ans8;
		$research_management->ques9 = $request->ques9;
		$research_management->ans9 = $request->ans9;
		$research_management->delete_status = '0';
        $research_management->save();
		$request->session()->flash('success','Report Updated Successfully');
		  return redirect('report_management');	
        echo "Testing";exit;
        
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
