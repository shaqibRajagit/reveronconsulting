<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\PressRelease;
use App\Models\research_management;
use DB;
class PressReleaseControler extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $Press = PressRelease::orderBy('id','desc')->paginate(5);
        return view('press_release',compact('Press'));
		return view('press_release');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		$request->validate([
		 'title'=>'required',
		 'url_title'=>'required',
		 'm_title'=>'required',
		 'm_keywords'=>'required',
		 'm_description'=>'required',
		 'article_text'=>'required',
		]);
		
		$PressRelease = new PressRelease;
		$PressRelease->title = $request->title;
        $PressRelease->url_title = $request->url_title;
        $PressRelease->m_title = $request->m_title;
        $PressRelease->m_keywords = $request->m_keywords;
        $PressRelease->m_description = $request->m_description;
        $PressRelease->article_text = $request->article_text;
        $PressRelease->save();
        
        $request->session()->flash('success','Post has been created successfully.');
		return redirect('add_press');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $PressRelease =  PressRelease::find($id);
		return view('edit_press',compact('PressRelease'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update_press(Request $request, $id)
    {
        $request->validate([
		 'title'=>'required',
		 'url_title'=>'required',
		 'm_title'=>'required',
		 'm_keywords'=>'required',
		 'm_description'=>'required',
		 'article_text'=>'required',
		]);
		$PressRelease = PressRelease::find($id);
		$PressRelease->title = $request->title;
        $PressRelease->url_title = $request->url_title;
        $PressRelease->m_title = $request->m_title;
        $PressRelease->m_keywords = $request->m_keywords;
        $PressRelease->m_description = $request->m_description;
        $PressRelease->article_text = $request->article_text;
        $PressRelease->save();
		
		$request->session()->flash('success','Rec updated successfully');
		
		  return redirect('add_press');	
		// echo "Testing";exit;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request,$id)
    {
       $PressRelease = PressRelease::findOrFail($id);
		$PressRelease->delete();
		$request->session()->flash('success','Record Deleted Successfully');
		return redirect('add_press');	
		
    }
	
	//Start Search
	
	function AjaxIndexs()
    {
     return view('live_search');
    }
	function actions(Request $request)
    {
     if($request->ajax())
     {
      $output = '';
      $query = $request->get('query');
      if($query != '')
      {
       $data = DB::table('press_releases')
         ->where('id', 'like', '%'.$query.'%')
         ->orWhere('title', 'like', '%'.$query.'%')
         ->orWhere('article_text', 'like', '%'.$query.'%')
         ->orderBy('id', 'desc')
         ->get();
         
      }
      else
      {
	   $data = DB::table('press_releases')
         ->orderBy('id', 'desc')
		 ->limit(20)
         ->get();
		/* 
	$data = DB::table('research_managements')
    ->join('client_news', 'research_managements.industry_id', '=', 'client_news.id')
	->select('research_managements.*','client_news.name as name')
    ->get();
	*/
	
      }
      $total_row = $data->count();
      // print_r($total_row);exit;
	  if($total_row > 0)
      {
       foreach($data as $row)
       {
        $output .= '
        <tr>
         <td>'.$row->id.'</td>
         
         <td style="width:200px">'.substr($row->title,0,50).'</td>
         <td>'.substr($row->article_text,0,100).'</td>
		 <td>
		  <form action="/destroy" method="POST">
    
                    <a class="btn btn-primary" href="edit_press/'.$row->id.'">Edit</a>
                    <a class="btn btn-danger" href="destroy/'.$row->id.'">Delete</a>
   
                    
                    
      
                    <!--<button type="submit" class="btn btn-danger">Delete</button>-->
                </form>
		 </td>
         </tr>
        ';
       }
      }
      else
      {
       $output = '
       <tr>
        <td align="center" colspan="5">No Data Found</td>
       </tr>
       ';
      }
      $data = array(
       'table_data'  => $output,
       'total_data'  => $total_row
      );

      echo json_encode($data);
     }
    }
	
	
	//End Search
}
