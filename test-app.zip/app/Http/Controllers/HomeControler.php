<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\client_new;
use App\Models\client_management;
use DB;
class HomeControler extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $client_new = client_new::orderBy('id','desc')->paginate(2);
		// print_r($client_managements);exit;
		return view('menu',compact('client_new'));
		// return view('menu');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
		$client_new = new client_new;
        $request->validate([
            'name' => 'required',
            'meta_title' => 'required',
            'meta_description' => 'required',
			'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
        ]);
		$imageName = '';
	   if($request->image){
		$imageName = time().'.'.$request->image->extension();
		
		$request->image->move(public_path('upload'),$imageName);
	    }
		$client_new->name = $request->name;
        $client_new->meta_title = $request->meta_title;
        $client_new->meta_description = $request->meta_description;
		$client_new->image = $imageName;
        
		$client_new->save();
		$request->session()->flash('success','Industry has been created successfully.');
		  return redirect('add_menu');		
		
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit_menu(client_new $client_new,$id)
    {
		$client_new = client_new::find($id);
		// print_r($client_new);exit;
		//$title = ['PHP','JAVA','ANGULAR'];
		return view('edit_menu',compact('client_new'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update_menu(Request $request, $id)
    {
        $request->validate([
            'name' => 'required',
			'meta_title' => 'required',
            'meta_description' => 'required',
        ]);
		$client_new = client_new::find($id);
		if($request->hasFile('image')){
            $request->validate([
              'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            ]);
        }
		$imageName = '';
	 if($request->image){
		$imageName = time().'.'.$request->image->extension();
		$request->image->move(public_path('upload'),$imageName);
        $client_new->image=$imageName;	
	 }
		$client_new->name = $request->name;
		$client_new->meta_title = $request->meta_title;
        $client_new->meta_description = $request->meta_description;
        //print_r($client_new);exit;
		$client_new->save();
		
		$request->session()->flash('success','Menu updated successfully');
		
		  return redirect('add_menu');	
    // echo "test";exit;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
	
	
	//Start Client Management
	  public function client()
    {
		$client_managements = client_management::orderBy('id','desc')->paginate(2);
		$client_management_Count = client_management::count();
		// print_r($client_managements);exit;
		return view('client_management',compact('client_managements','client_management_Count'));
        // return view('client_management')->with('users', $users);
        // return view('client_management');
    }
	public function storeClient(Request $request)
    {
		
        $request->validate([
            'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            
        ]);
        //$path = $request->file('image')->store('public/images');
        
		$imageName = '';
	 if($request->image){
		$imageName = time().'.'.$request->image->extension();
		
		$request->image->move(public_path('upload'),$imageName);
	 }
		
		$client_management = new client_management;
        $client_management->title = $request->title;
        $client_management->image = $imageName;
        $client_management->save();
        
        $request->session()->flash('success','Client Management has been created successfully.');
		  return redirect('client_management');		
        //return redirect()->route('/posts')
                        //->with('success','Post has been created successfully.');
    } 
	
	public function edit_client(client_management $client_management,$id)
    {
		$client_management = client_management::find($id);
		return view('client_edit',compact('client_management'));
    }
	
	public function update_client(Request $request, $id)
    {
		$request->validate([
            //'title' => 'required',
        ]);
        
        $client_management = client_management::find($id);
        if($request->hasFile('image')){
            $request->validate([
              'image' => 'required|image|mimes:jpg,png,jpeg,gif,svg|max:2048',
            ]);
        }
		$imageName = '';
	 if($request->image){
		$imageName = time().'.'.$request->image->extension();
		$request->image->move(public_path('upload'),$imageName);
        $client_management->image=$imageName;	
	 }
	 
        $client_management->title = $request->title;
        
		$client_management->save();
		
		$request->session()->flash('success','Client Management updated successfully');
		
		  return redirect('client_management');	
    
        //return redirect()->route('/posts')
                        //->with('success','Post updated successfully');
    }
	//End Client Management
	
}
