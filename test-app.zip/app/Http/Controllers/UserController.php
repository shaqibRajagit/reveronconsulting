<?php

namespace App\Http\Controllers;
use App\Exports\UsersExport;
use App\Imports\UsersImport;
use Illuminate\Http\Request;
use Excel;
class UserController extends Controller
{
    
  public function exportUser(){
	  
	  // dd("Export");
	  return Excel::download(new UsersExport,'user.xlsx');
  }
  public function importUser(Request $request){
	  // dd("Import");
	Excel::import(new UsersImport, $request->file('file'));
	return redirect('excel');	
  }
}
