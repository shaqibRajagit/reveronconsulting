<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="./home">
                        <i class="fa fa-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                
                <li class="sub-menu">
                    <a href="javascript:;">
                        <i class="fa fa-book"></i>
                        <span>Master</span>
                    </a>
                    <ul class="sub">
						<li><a href="./add_press">Manage Press Release</a></li>
						<li><a href="./excel">Excel Import</a></li>
                        <!--<li><a href="grids.html">Grids</a></li>-->
                    </ul>
                </li>
                <li>
                    <a href="report_management">
                        <i class="fa fa-bullhorn"></i>
                        <span>Report Management </span>
                    </a>
                </li>
				<li>
                    <a href="./add_menu">
                        <i class="fa fa-bullhorn"></i>
                        <span>Industry Management</span>
                    </a>
                </li>
                <li>
                    <a href="./client_management">
                        <i class="fa fa-bullhorn"></i>
                        <span>Image Upload </span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>