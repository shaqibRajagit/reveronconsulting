<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<head>
<script src="ckeditor/ckeditor.js"></script>
<title>Visitors an Admin Panel Category Bootstrap Responsive Website Template | Home :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="{{ asset('/css/bootstrap.min.css') }}" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="{{ asset('/css/style.css') }}" rel='stylesheet' type='text/css' />
<link href="{{ asset('/css/style-responsive.css') }}" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="{{ asset('/css/font.css') }}" type="text/css"/>
<link href="{{ asset('/css/font-awesome.css') }}" rel="stylesheet"> 
<link rel="stylesheet" href="{{ asset('/css/morris.css') }}" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="{{ asset('/css/monthly.css') }}">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="{{ asset('/js/jquery2.0.3.min.js') }}"></script>
<script src="{{ asset('/js/raphael-min.js') }}"></script>
<script src="{{ asset('/js/morris.js') }}"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a href="index.html" class="logo">
        VISITORS
    </a>
    <div class="sidebar-toggle-box">
        <div class="fa fa-bars"></div>
    </div>
</div>
<!--logo end-->
<div class="nav notify-row" id="top_menu">
    <!--  notification start -->
    <ul class="nav top-menu">
        <!-- settings start -->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-tasks"></i>
                <span class="badge bg-success">8</span>
            </a>
            <ul class="dropdown-menu extended tasks-bar">
                <li>
                    <p class="">You have 8 pending tasks</p>
                </li>
                <li>
                    <a href="#">
                        <div class="task-info clearfix">
                            <div class="desc pull-left">
                                <h5>Target Sell</h5>
                                <p>25% , Deadline  12 June’13</p>
                            </div>
                                    <span class="notification-pie-chart pull-right" data-percent="45">
                            <span class="percent"></span>
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="task-info clearfix">
                            <div class="desc pull-left">
                                <h5>Product Delivery</h5>
                                <p>45% , Deadline  12 June’13</p>
                            </div>
                                    <span class="notification-pie-chart pull-right" data-percent="78">
                            <span class="percent"></span>
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="task-info clearfix">
                            <div class="desc pull-left">
                                <h5>Payment collection</h5>
                                <p>87% , Deadline  12 June’13</p>
                            </div>
                                    <span class="notification-pie-chart pull-right" data-percent="60">
                            <span class="percent"></span>
                            </span>
                        </div>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <div class="task-info clearfix">
                            <div class="desc pull-left">
                                <h5>Target Sell</h5>
                                <p>33% , Deadline  12 June’13</p>
                            </div>
                                    <span class="notification-pie-chart pull-right" data-percent="90">
                            <span class="percent"></span>
                            </span>
                        </div>
                    </a>
                </li>

                <li class="external">
                    <a href="#">See All Tasks</a>
                </li>
            </ul>
        </li>
        <!-- settings end -->
        <!-- inbox dropdown start-->
        <li id="header_inbox_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <i class="fa fa-envelope-o"></i>
                <span class="badge bg-important">4</span>
            </a>
            <ul class="dropdown-menu extended inbox">
                <li>
                    <p class="red">You have 4 Mails</p>
                </li>
                <li>
                    <a href="#">
                        <span class="photo"><img alt="avatar" src="images/3.png"></span>
                                <span class="subject">
                                <span class="from">Jonathan Smith</span>
                                <span class="time">Just now</span>
                                </span>
                                <span class="message">
                                    Hello, this is an example msg.
                                </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="photo"><img alt="avatar" src="images/1.png"></span>
                                <span class="subject">
                                <span class="from">Jane Doe</span>
                                <span class="time">2 min ago</span>
                                </span>
                                <span class="message">
                                    Nice admin template
                                </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="photo"><img alt="avatar" src="images/3.png"></span>
                                <span class="subject">
                                <span class="from">Tasi sam</span>
                                <span class="time">2 days ago</span>
                                </span>
                                <span class="message">
                                    This is an example msg.
                                </span>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <span class="photo"><img alt="avatar" src="images/2.png"></span>
                                <span class="subject">
                                <span class="from">Mr. Perfect</span>
                                <span class="time">2 hour ago</span>
                                </span>
                                <span class="message">
                                    Hi there, its a test
                                </span>
                    </a>
                </li>
                <li>
                    <a href="#">See all messages</a>
                </li>
            </ul>
        </li>
        <!-- inbox dropdown end -->
        <!-- notification dropdown start-->
        <li id="header_notification_bar" class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">

                <i class="fa fa-bell-o"></i>
                <span class="badge bg-warning">3</span>
            </a>
            <ul class="dropdown-menu extended notification">
                <li>
                    <p>Notifications</p>
                </li>
                <li>
                    <div class="alert alert-info clearfix">
                        <span class="alert-icon"><i class="fa fa-bolt"></i></span>
                        <div class="noti-info">
                            <a href="#"> Server #1 overloaded.</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="alert alert-danger clearfix">
                        <span class="alert-icon"><i class="fa fa-bolt"></i></span>
                        <div class="noti-info">
                            <a href="#"> Server #2 overloaded.</a>
                        </div>
                    </div>
                </li>
                <li>
                    <div class="alert alert-success clearfix">
                        <span class="alert-icon"><i class="fa fa-bolt"></i></span>
                        <div class="noti-info">
                            <a href="#"> Server #3 overloaded.</a>
                        </div>
                    </div>
                </li>

            </ul>
        </li>
        <!-- notification dropdown end -->
    </ul>
    <!--  notification end -->
</div>
<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li>
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/2.png">
                <span class="username">John Doe</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                <li><a href="login.html"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<!--sidebar start-->
@include('layouts.sidebar');

<!--sidebar end-->
<!--main content start-->
<section id="main-content" class="wrapper">

     <section class="panel">
            <header class="panel-heading">
                <!-- //market-->
		@if(session('success'))
			
          <!--<script>
    window.location = "/home";
  </script>-->
    <div class="alert alert-success mb-1 mt-1">
        {{ session('success') }}
    </div>
  @endif
		<!-- //market-->
            </header>
            <div class="panel-body">
                <form class="form-horizontal bucket-form" action="/store" method="POST">
                    @csrf
					<div class="form-group">
                        <label class="col-sm-3 control-label">Select Menu </label>
                        <div class="col-sm-6">
                            <select name="title" id="title">
	                          <option value="">SELECT SERVICES</option>
	                          <option value="PHP">PHP</option>
	                          <option value="JAVA">JAVA</option>
	                          <option value="ANGULAR">ANGULAR</option>
                            </select>
							@error('title')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Title	</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="title" id="title	" placeholder="Enter title">
							@error('title')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">URL title</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="url_title" id="meta_title" placeholder="Enter Meta Title">
							@error('url_title')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Sub Industry</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="name" id="sub_industry" placeholder="Enter sub_industry">
							@error('sub_industry')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Article Text</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="article_text" id="meta_title" placeholder="Enter Meta Title">
							@error('article_text')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Company Mentioned</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="company_mentioned" id="meta_description" placeholder="Meta Description">
							@error('company_mentioned')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				        
						
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Table Content</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="table_content" id="name" placeholder="Enter Menu Name">
							@error('table_content')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Price Single User</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="price_single_user" id="meta_title" placeholder="Enter Meta Title">
							@error('price_single_user')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Price Multi User</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="price_multi_user" id="meta_description" placeholder="Meta Description">
							@error('price_multi_user')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				        
						
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Price Industry User</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="price_industry_user" id="name" placeholder="Enter Menu Name">
							@error('price_industry_user')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Page Count</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="page_count" id="meta_title" placeholder="Enter Meta Title">
							@error('page_count')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Meta Title</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="m_title" id="meta_description" placeholder="Meta Description">
							@error('m_title')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				        
						
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Meta Keywords</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="m_keywords" id="name" placeholder="Enter Menu Name">
							@error('m_keywords')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">M Description</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="m_description" id="meta_title" placeholder="Enter Meta Title">
							@error('m_description')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">FAQ Keyword</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="faq_keyword" id="meta_description" placeholder="Meta Description">
							@error('faq_keyword')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				        
						
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Ques1</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ques1" id="name" placeholder="Enter Menu Name">
							@error('ques1')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Ques2</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ques2" id="meta_title" placeholder="Enter Meta Title">
							@error('ques2')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Ques3</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="ques3" id="meta_description" placeholder="Meta Description">
							@error('ques3')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				        
						
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Ques4</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ques4" id="name" placeholder="Enter Menu Name">
							@error('ques4')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Ques5</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ques5" id="meta_title" placeholder="Enter Meta Title">
							@error('ques5')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Ques6</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="ques6" id="meta_description" placeholder="Meta Description">
							@error('ques6')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				      
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Quesa7</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="quesa7" id="name" placeholder="Enter Menu Name">
							@error('quesa7')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Ans7</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ans7" id="meta_title" placeholder="Enter Meta Title">
							@error('ans7')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Quesa8</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="quesa8" id="meta_description" placeholder="Meta Description">
							@error('quesa8')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				       
						</div>
						
                    </div>
					
					<div class="form-group">
                        <label class="col-sm-3 control-label">Ans8</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="ans8" id="name" placeholder="Enter Menu Name">
							@error('ans8')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
               @enderror
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Region</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="region" id="meta_title" placeholder="Enter Meta Title">
							@error('region')
                  <div class="alert alert-danger mt-1 mb-1">{{ $message }}</div>
                @enderror
				
				           <br/>
                        <button type="submit" class="btn btn-primary ml-3">Submit</button>
				
                        </div>
                    </div>
					
                </form>
            </div>
        </section>



	<section style="margin-right:150px;">
		
		
	<!--<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group" style="height:50px;background:#3b3e54b8;">
                  
            </div>
        </div>-->





<div class="container box">
   <h3 align="center">Live search</h3><br />
   <div class="panel panel-default" style="margin-right: 90px;">
    <div class="panel-heading">Search Customer Data</div>
    <div class="panel-body">
     <div class="form-group">
      <input type="text" name="search" id="search" class="form-control" placeholder="Search Customer Data" />
     </div>
     <div class="table-responsive">
      <h3 align="center">Total Data : <span id="total_records"></span></h3>
      <table class="table table-striped table-bordered">
       <thead>
        <tr>
		 <th>ID</th>
         <th>Menu Name</th>
         <th>Meta Title</th>
         <th>Meta Description</th>
		 <th>Status</th>
		
        </tr>
       </thead>
       <tbody>

       </tbody>
      </table>
     </div>
    </div>    
   </div>
  </div>
<script type="text/javascript">
        CKEDITOR.replace( 'report_details' );
</script>
	  
<script>
$(document).ready(function(){

 fetch_customer_data();

 function fetch_customer_data(query = '')
 {
  $.ajax({
   url:"{{ route('live_search_menu.action') }}",
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('tbody').html(data.table_data);
    $('#total_records').text(data.total_data);
   }
  })
 }

 $(document).on('keyup', '#search', function(){
  var query = $(this).val();
  fetch_customer_data(query);
 });
});
</script>
		
</section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2017 Visitors. All rights reserved | Design by <a href="http://w3layouts.com">W3layouts</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="{{ asset('/js/bootstrap.js') }}"></script>
<script src="{{ asset('/js/jquery.dcjqaccordion.2.7.js') }}"></script>
<script src="{{ asset('/js/scripts.js') }}"></script>
<script src="{{ asset('/js/jquery.slimscroll.js') }}"></script>
<script src="{{ asset('/js/jquery.nicescroll.js') }}"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="{{ asset('/js/jquery.scrollTo.js') }}"></script>
<!-- morris JavaScript -->
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
