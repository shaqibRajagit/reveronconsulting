<!DOCTYPE html>
<head>
<script src="ckeditor/ckeditor.js"></script>
<title>Admin Panel</title>
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- bootstrap-css -->
<link rel="stylesheet" href="<?php echo e(asset('/css/bootstrap.min.css')); ?>" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="<?php echo e(asset('/css/style.css')); ?>" rel='stylesheet' type='text/css' />
<link href="<?php echo e(asset('/css/style-responsive.css')); ?>" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="<?php echo e(asset('/css/font.css')); ?>" type="text/css"/>
<link href="<?php echo e(asset('/css/font-awesome.css')); ?>" rel="stylesheet"> 
<link rel="stylesheet" href="<?php echo e(asset('/css/morris.css')); ?>" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="<?php echo e(asset('/css/monthly.css')); ?>">
<!-- //calendar -->
<!-- //font-awesome icons -->
<script src="<?php echo e(asset('/js/jquery2.0.3.min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('/js/morris.js')); ?>"></script>
</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a style="font-weight:bold;color:#868f0b;;margin-left:300px;" href="./home" class="logo">
        
		Industry/Management
    </a>
</div>

<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
       
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/shaqib.jpg">
                <span class="username">Shaqib</span>
                <b class="caret"></b>
            </a>
            <ul class="dropdown-menu extended logout">
                <li><a href="#"><i class=" fa fa-suitcase"></i>Profile</a></li>
                <li><a href="#"><i class="fa fa-cog"></i> Settings</a></li>
                <li><a href="login.html"><i class="fa fa-key"></i> Log Out</a></li>
            </ul>
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>



<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


<!--sidebar start-->
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

<!--sidebar end-->
<!--main content start-->
<section id="main-content" class="wrapper">

     <section class="panel">
            <header class="panel-heading">
                <!-- //market-->
		<?php if(session('success')): ?>
			
          <!--<script>
    window.location = "/home";
  </script>-->
    <div class="alert alert-success mb-1 mt-1">
        <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>
		<!-- //market-->
            </header>
            <div class="panel-body">
                <form class="form-horizontal bucket-form" action="/store" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
					<div class="form-group">
                        <label class="col-sm-3 control-label">Industry Name</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="name" id="name" placeholder="Enter Menu Name">
							<?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Meta Title</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control" name="meta_title" id="meta_title" placeholder="Enter Meta Title">
							<?php $__errorArgs = ['meta_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-3 control-label">Meta Description</label>
                        <div class="col-sm-6">
                            <input type="text" class="form-control round-input" name="meta_description" id="meta_description" placeholder="Meta Description">
							<?php $__errorArgs = ['meta_description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				        
						
						</div>
						
                    </div>
					<div class="form-group">
                        <label class="col-sm-3 control-label">Meta Title</label>
                        <div class="col-sm-6">
                            
                 <input type="file" name="image" class="form-control" >
                <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <div class="alert alert-danger mt-1 mb-1"><?php echo e($message); ?></div>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
						
						<br/>
                        <button type="submit" class="btn btn-primary ml-3">Submit</button>
                    </div>
					
					
                </form>
            </div>
        </section>



	<section style="margin-right:150px;">
		
		
	<!--<div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group" style="height:50px;background:#3b3e54b8;">
                  
            </div>
        </div>-->





<div class="container box">
   
   <div class="panel panel-default" style="margin-right: 90px;">
    <div class="panel-body">
     <div class="form-group">
      <input type="text" name="search" id="search" class="form-control" placeholder="Search Customer Data" />
     </div>
     <div class="table-responsive">
      <h3 align="center">Total Data : <span id="total_records"></span></h3>
      <table class="table table-striped table-bordered">
       <thead>
        <tr>
		 <th>ID</th>
         <th>Menu Name</th>
         <th>Meta Title</th>
         <th>Meta Description</th>
		 <th>Image</th>
		 <th>Action</th>
		
        </tr>
       </thead>
       <tbody>
	   <?php $__currentLoopData = $client_new; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <tr>
		 <td><?php echo e($client->id); ?></td>
         <td><?php echo e($client->name); ?></td>
         <td><?php echo e($client->meta_title); ?></td>
         <td><?php echo e($client->meta_description); ?></td>
		 <td><img src="<?php echo e(asset('upload/'.$client->image)); ?>" height="200" width="200" alt="" /></td>
		 <td><a class="btn btn-primary" href="edit_menu/<?php echo e($client->id); ?>">Edit</a>
                    <a class="btn btn-danger" href="destroy/<?php echo e($client->id); ?>">Delete</a></td>
        </tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		
       </tbody>
      </table>
	  <div class="page-nav">
							<?php echo e($client_new->links('pagination::bootstrap-4')); ?>

			            </div>
     </div>
    </div>    
   </div>
  </div>
<script type="text/javascript">
        CKEDITOR.replace( 'report_details' );
</script>
	  
<script>
$(document).ready(function(){

 fetch_customer_data();

 function fetch_customer_data(query = '')
 {
  $.ajax({
   url:"<?php echo e(route('live_search_menu.action')); ?>",
   method:'GET',
   data:{query:query},
   dataType:'json',
   success:function(data)
   {
    $('tbody').html(data.table_data);
    $('#total_records').text(data.total_data);
   }
  })
 }

 $(document).on('keyup', '#search', function(){
  var query = $(this).val();
  fetch_customer_data(query);
 });
});
</script>
		
</section>
 <!-- footer -->
		  <div class="footer">
			<div class="wthree-copyright">
			  <p>© 2022 Visitors. All rights reserved | Design by <a href="#">Kennethresearch</a></p>
			</div>
		  </div>
  <!-- / footer -->
</section>
<!--main content end-->
</section>
<script src="<?php echo e(asset('/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.dcjqaccordion.2.7.js')); ?>"></script>
<script src="<?php echo e(asset('/js/scripts.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.slimscroll.js')); ?>"></script>
<script src="<?php echo e(asset('/js/jquery.nicescroll.js')); ?>"></script>
<!--[if lte IE 8]><script language="javascript" type="text/javascript" src="js/flot-chart/excanvas.min.js"></script><![endif]-->
<script src="<?php echo e(asset('/js/jquery.scrollTo.js')); ?>"></script>
<!-- morris JavaScript -->
<script>
	$(document).ready(function() {
		//BOX BUTTON SHOW AND CLOSE
	   jQuery('.small-graph-box').hover(function() {
		  jQuery(this).find('.box-button').fadeIn('fast');
	   }, function() {
		  jQuery(this).find('.box-button').fadeOut('fast');
	   });
	   jQuery('.small-graph-box .box-close').click(function() {
		  jQuery(this).closest('.small-graph-box').fadeOut(200);
		  return false;
	   });
	   
	    //CHARTS
	    function gd(year, day, month) {
			return new Date(year, month - 1, day).getTime();
		}
		
		graphArea2 = Morris.Area({
			element: 'hero-area',
			padding: 10,
        behaveLikeLine: true,
        gridEnabled: false,
        gridLineColor: '#dddddd',
        axes: true,
        resize: true,
        smooth:true,
        pointSize: 0,
        lineWidth: 0,
        fillOpacity:0.85,
			data: [
				{period: '2015 Q1', iphone: 2668, ipad: null, itouch: 2649},
				{period: '2015 Q2', iphone: 15780, ipad: 13799, itouch: 12051},
				{period: '2015 Q3', iphone: 12920, ipad: 10975, itouch: 9910},
				{period: '2015 Q4', iphone: 8770, ipad: 6600, itouch: 6695},
				{period: '2016 Q1', iphone: 10820, ipad: 10924, itouch: 12300},
				{period: '2016 Q2', iphone: 9680, ipad: 9010, itouch: 7891},
				{period: '2016 Q3', iphone: 4830, ipad: 3805, itouch: 1598},
				{period: '2016 Q4', iphone: 15083, ipad: 8977, itouch: 5185},
				{period: '2017 Q1', iphone: 10697, ipad: 4470, itouch: 2038},
			
			],
			lineColors:['#eb6f6f','#926383','#eb6f6f'],
			xkey: 'period',
            redraw: true,
            ykeys: ['iphone', 'ipad', 'itouch'],
            labels: ['All Visitors', 'Returning Visitors', 'Unique Visitors'],
			pointSize: 2,
			hideHover: 'auto',
			resize: true
		});
		
	   
	});
	</script>
<!-- calendar -->
	<script type="text/javascript" src="js/monthly.js"></script>
	<script type="text/javascript">
		$(window).load( function() {

			$('#mycalendar').monthly({
				mode: 'event',
				
			});

			$('#mycalendar2').monthly({
				mode: 'picker',
				target: '#mytarget',
				setWidth: '250px',
				startHidden: true,
				showTrigger: '#mytarget',
				stylePast: true,
				disablePast: true
			});

		switch(window.location.protocol) {
		case 'http:':
		case 'https:':
		// running on a server, should be good.
		break;
		case 'file:':
		alert('Just a heads-up, events will not work when run locally.');
		}

		});
	</script>
	<!-- //calendar -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\ddd\test-app\resources\views/menu.blade.php ENDPATH**/ ?>