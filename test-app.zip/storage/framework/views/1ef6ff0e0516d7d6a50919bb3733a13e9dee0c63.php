
                                 <div class="table-responsive">
     <table class="table table-striped table-bordered">
      <tr>
       <th width="5%">ID</th>
       <th width="38%">Title</th>
       <th width="57%">Description</th>
      </tr>
      <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
       <td><?php echo e($row->id); ?></td>
       <td><?php echo e($row->name); ?></td>
       <td><?php echo e($row->meta_title); ?></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     </table>

     <?php echo $data->links(); ?>


    </div><?php /**PATH C:\xampp\htdocs\ddd\test-app\resources\views/pagination_data.blade.php ENDPATH**/ ?>