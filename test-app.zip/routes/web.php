<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeControler;
use App\Http\Controllers\research_management_page;
use App\Http\Controllers\Dynamicfield;
use App\Http\Controllers\PaginationController;
use App\Http\Controllers\PressReleaseControler;
use App\Http\Controllers\UserController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

/*
Route::get('/', function () {
    return view('index');
});*/
Route::get('/logind', function () {
    return view('login');
});

Route::group(['middleware'=>'guest'],function(){
    Route::get('login',[AuthController::class,'index'])->name('login');
    Route::post('login',[AuthController::class,'login'])->name('login')->middleware('throttle:2,1');

    Route::get('register',[AuthController::class,'register_view'])->name('register');
    Route::post('register',[AuthController::class,'register'])->name('register')->middleware('throttle:2,1');
});



Route::group(['middleware'=>'auth'],function(){
    
	Route::get('home',[AuthController::class,'home'])->name('home');
	/*
	Route::get('report_management',[AuthController::class,'report_management'])->name('report_management');
    Route::post('storess',[AuthController::class,'storess']);
	Route::get('report_management',[AuthController::class,'reports']);
	Route::get('edit/{id}',[AuthController::class,'edit']);
	Route::put('update/{id}',[AuthController::class,'update']);
	Route::get("search",[AuthController::class,'search']);
	*/
	
	Route::get('add_menu',[HomeControler::class,'create'])->name('add_menu');
	Route::get("live_search_menu",[HomeControler::class,'AjaxIndex_menu']);
	Route::get('edit_menu/{id}',[HomeControler::class,'edit_menu']);
	Route::put('update_menu/{id}',[HomeControler::class,'update_menu']);
	Route::get("live_search_menu/action",[HomeControler::class,'action_menu'])->name('live_search_menu.action');
	Route::post('store',[HomeControler::class,'store']);
	//Start Research Management
	//Route::get('add_report_management',[research_management::class,'create'])->name('add_report_management');
	//End Research Management
	
	//Start Ajax Paginartion
	Route::get('/pagination', 'App\Http\Controllers\PaginationController@index');
Route::get('pagination/fetch_data', 'App\Http\Controllers\PaginationController@fetch_data');
	//End Ajax Paginartion
	/*
	Route::get("live_search",[AuthController::class,'AjaxIndex']);
Route::get("live_search/action",[AuthController::class,'action'])->name('live_search.action');*/
	
	Route::get('logout',[AuthController::class,'logout'])->name('logout');
	
	//Start Client Management
	  Route::get('client_management',[HomeControler::class,'client']);
	  Route::post('storeClient',[HomeControler::class,'storeClient']);
	  Route::get('client_edit/{id}',[HomeControler::class,'edit_client']);
	  Route::put('update_client/{id}',[HomeControler::class,'update_client']);
	//End Client Management
	//Start research_management
	  // Route::get('report_management',[research_management::class,'index'])->name('report_management');
      Route::post('store_data',[research_management_page::class,'store']);
	  Route::get('report_management',[research_management_page::class,'index']);
	  Route::get('edit_report/{id}',[research_management_page::class,'edit']);
	  Route::put('update_report/{id}',[research_management_page::class,'update_report']);
	  Route::get("",[research_management_page::class,'search']);
	  
	  Route::get("live_search",[research_management_page::class,'AjaxIndex']);
Route::get("live_search/action",[research_management_page::class,'action'])->name('live_search.action');
	//End research_management
	
	//Start Press Release 
	  Route::get('add_press',[PressReleaseControler::class,'index']);
	  Route::post('store_press',[PressReleaseControler::class,'store']);
	  Route::get('edit_press/{id}',[PressReleaseControler::class,'edit']);
	  Route::put('update_press/{id}',[PressReleaseControler::class,'update_press']);
	  Route::get('destroy/{id}',[PressReleaseControler::class,'destroy']);
	  Route::get("live_search_press",[PressReleaseControler::class,'AjaxIndexs']);
Route::get("live_search_press.actions",[PressReleaseControler::class,'actions'])->name('live_search_press.actions');
	//End Press Release
	
	//Start Excel Import
	  Route::get('excel', function () {
       return view('excel');
      });
      Route::get('export-user',[UserController::class,'exportUser'])->name('export-user');
      Route::post('import-user',[UserController::class,'importUser'])->name('import-user');
	//End Excel Import
	
	//Start Dynamic
	  Route::get('dynamic',[Dynamicfield::class,'index']);
	  Route::post('store_dynamic',[Dynamicfield::class,'store']);
	//End Dynamic
	
});

